
package rg_HuoShan.AnZhuo.JiBen;

public class rg_BiaoShiFuLei  {
    public rg_BiaoShiFuLei ()  { }
    public String rg_BiaoShiFu3 = "";
}
