
package rg_HuoShan.AnZhuo.JiTong;

abstract class AndroidManifestElement  {
    public AndroidManifestElement ()  { }
}
