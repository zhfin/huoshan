
package rg_HuoShan.AnZhuo.ChuangKou;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class rg_XianXingBuJuQi extends AndroidViewGroup  {
    public rg_XianXingBuJuQi ()  { }
    public rg_XianXingBuJuQi (LinearLayout layouter) { super (layouter); }
}
