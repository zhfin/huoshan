
package rg_HuoShan.AnZhuo.ChuangKou;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class rg_ZhengBuJuQi extends AndroidViewGroup  {
    public rg_ZhengBuJuQi ()  { }
    public rg_ZhengBuJuQi (LinearLayout layouter) { super (layouter); }
}
