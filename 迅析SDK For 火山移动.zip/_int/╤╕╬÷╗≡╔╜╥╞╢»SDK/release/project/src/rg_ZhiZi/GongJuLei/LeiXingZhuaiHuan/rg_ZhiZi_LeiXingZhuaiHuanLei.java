
package rg_ZhiZi.GongJuLei.LeiXingZhuaiHuan;

public class rg_ZhiZi_LeiXingZhuaiHuanLei  {
    public rg_ZhiZi_LeiXingZhuaiHuanLei ()  { }
    public static int rg_WenBenDaoZhengShu (String rg_YuZhuaiHuanDeWenBen)  {
        try { return Integer.parseInt (rg_YuZhuaiHuanDeWenBen); } catch (Exception e) { } return 0;
    }
    public byte [] rg_WenBenDaoZiJieJi (String rg_YuZhuaiHuanDeWenBen1)  {
        try { return rg_YuZhuaiHuanDeWenBen1.getBytes(); } catch (Exception e) { } return null;
    }
    public boolean rg_WenBenDaoLuoJi (String rg_YuZhuaiHuanDeWenBen2)  {
        try { return Boolean.getBoolean(rg_YuZhuaiHuanDeWenBen2); } catch (Exception e) { } return false;
    }
    public static String rg_ZhengShuDaoWenBen (int rg_YuZhuaiHuanDeZhengShu)  {
        try { return Integer.toString(rg_YuZhuaiHuanDeZhengShu); } catch (Exception e) { } return "";
    }
    public static String rg_ZhengShuDaoWenBen_JiTaJinZhi (int rg_YuZhuaiHuanDeZhengShu1, int rg_JinZhi)  {
        try { return Integer.toString(rg_YuZhuaiHuanDeZhengShu1, rg_JinZhi); } catch (Exception e) { } return "";
    }
    public static String rg_ZiJieJiDaoWenBen (byte [] rg_YuZhuaiHuanDeZiJieJi)  {
        try { return new String(rg_YuZhuaiHuanDeZiJieJi); } catch (Exception e) { } return "";
    }
    public static String rg_ChangZhengXingDaoWenBen (long rg_YuZhuaiHuanDeChangZhengShu)  {
        try { return Long.toString(rg_YuZhuaiHuanDeChangZhengShu); } catch (Exception e) { } return "";
    }
}
