
package rg_ZhiZi.GongJuLei.WenBen;

public class rg_ZhiZi_WenBenGongJuLei  {
    public rg_ZhiZi_WenBenGongJuLei ()  { }
    public static final String rg_HuanHangFu = "\n";
    public static boolean rg_ShiFouXiangDeng (String rg_YuanWenBen, String rg_MuBiaoWenBen)  {
        if(rg_YuanWenBen == null || rg_MuBiaoWenBen == null) return true;
        if(rg_YuanWenBen == null || rg_MuBiaoWenBen == null) return false;
        return rg_YuanWenBen.equals (rg_MuBiaoWenBen);
    }
    public static boolean rg_ShiFouXiangDeng_BuOuFenDaXiaoXie (String rg_YuanWenBen1, String rg_MuBiaoWenBen1)  {
        if(rg_YuanWenBen1 == null || rg_MuBiaoWenBen1 == null) return true;
        if(rg_YuanWenBen1 == null || rg_MuBiaoWenBen1 == null) return false;
        return rg_YuanWenBen1.equalsIgnoreCase (rg_MuBiaoWenBen1);
    }
    public static int rg_QuWenBenChangDu (String rg_YuanWenBen2)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen2))
        {
            return (0);
        }
        return rg_YuanWenBen2.length ();
    }
    public static char rg_QuZiFu (String rg_YuanWenBen3, int rg_YuQuWeiZhi)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen3))
        {
            return (0);
        }
        return rg_YuanWenBen3.charAt(rg_YuQuWeiZhi);
    }
    public static String rg_ShanShouWeiKong (String rg_YuanWenBen4)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen4))
        {
            return ("");
        }
        return rg_YuanWenBen4.trim();
    }
    public static String rg_DaoDaXie (String rg_YuanWenBen5)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen5))
        {
            return ("");
        }
        return rg_YuanWenBen5.toUpperCase();
    }
    public static String rg_DaoXiaoXie (String rg_YuanWenBen6)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen6))
        {
            return ("");
        }
        return rg_YuanWenBen6.toLowerCase();
    }
    public static String rg_JiaRuWenBen (String rg_YuanWenBen7, String rg_YuTianJiaDeWenBen)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen7))
        {
            return (rg_YuTianJiaDeWenBen);
        }
        if (rg_ShiFouWeiKong (rg_YuTianJiaDeWenBen))
        {
            return (rg_YuanWenBen7);
        }
        return rg_YuanWenBen7.concat(rg_YuTianJiaDeWenBen);
    }
    public static String rg_JiaRuWenBen_HuanHangFu (String rg_YuanWenBen8, String rg_YuTianJiaDeWenBen1)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen8))
        {
            return (rg_YuTianJiaDeWenBen1);
        }
        if (rg_ShiFouWeiKong (rg_YuTianJiaDeWenBen1))
        {
            return (rg_YuanWenBen8);
        }
        return rg_YuanWenBen8.concat(rg_YuTianJiaDeWenBen1).concat(rg_HuanHangFu);
    }
    public static String [] rg_FenGeWenBen (String rg_YuanWenBen9, String rg_FenGeFu, int rg_FenGeDeFenShu)  {
        if (rg_ShiFouWeiKong (rg_YuanWenBen9) || rg_ShiFouWeiKong (rg_FenGeFu))
        {
            return null;
        }
        if (rg_FenGeDeFenShu == 0)
        {
            return rg_YuanWenBen9.split(rg_FenGeFu);
        }
        else
        {
            return rg_YuanWenBen9.split(rg_FenGeFu, rg_FenGeDeFenShu);
        }

    }
    public static boolean rg_ShiFouWeiKong (String rg_YuanWenBen10)  {
        return rg_YuanWenBen10 == null || rg_YuanWenBen10.isEmpty();
    }
    public static int rg_XinZhaoWenBen (String rg_YuanWenBen11, String rg_XuYaoXinZhaoDeWenBen, int rg_KaiShiWeiZhi)  {
        if (rg_KaiShiWeiZhi < 0 || rg_KaiShiWeiZhi > rg_QuWenBenChangDu (rg_YuanWenBen11) || rg_ShiFouWeiKong (rg_YuanWenBen11) || rg_ShiFouWeiKong (rg_XuYaoXinZhaoDeWenBen))
        {
            return (-1);
        }
        return rg_YuanWenBen11.indexOf(rg_XuYaoXinZhaoDeWenBen);
    }
    public static String rg_QuZiWenBen (String rg_YuanWenBen12, int rg_QiShiWeiZhi, int rg_JieShuWeiZhi)  {
        if (rg_JieShuWeiZhi != 0 && rg_QiShiWeiZhi > rg_JieShuWeiZhi || rg_ShiFouWeiKong (rg_YuanWenBen12) || rg_QuWenBenChangDu (rg_YuanWenBen12) < rg_JieShuWeiZhi)
        {
            return ("");
        }
        if (rg_JieShuWeiZhi == 0)
        {
            return rg_YuanWenBen12.substring(rg_QiShiWeiZhi);
        }
        else
        {
            return rg_YuanWenBen12.substring(rg_QiShiWeiZhi, rg_JieShuWeiZhi);
        }
    }
    public static String rg_WenBenTiHuan (String rg_YuanWenBen13, String rg_YuBeiTiHuanDeWenBen, String rg_YuDaiTiDeWenBen)  {
        return rg_YuanWenBen13.replace(rg_YuBeiTiHuanDeWenBen, rg_YuDaiTiDeWenBen);
    }
    public static String rg_QuChuZhongJianWenBen (String rg_YuQuQuanWenBen, String rg_QianMianWenBen, String rg_HouMianWenBen, int rg_QiShiSouXinWeiZhi)  {
        int rg_Ju_WeiZhi;
        int rg_Ju_WeiZhi1;
        rg_Ju_WeiZhi = rg_XinZhaoWenBen (rg_YuQuQuanWenBen, rg_QianMianWenBen, rg_QiShiSouXinWeiZhi);
        if (rg_Ju_WeiZhi != -1)
        {
            rg_Ju_WeiZhi = rg_Ju_WeiZhi + rg_QuWenBenChangDu (rg_QianMianWenBen);
        }
        rg_Ju_WeiZhi1 = rg_XinZhaoWenBen (rg_YuQuQuanWenBen, rg_HouMianWenBen, rg_Ju_WeiZhi);
        if (rg_Ju_WeiZhi == -1 || rg_Ju_WeiZhi1 == -1)
        {
            return ("");
        }
        return (rg_QuZiWenBen (rg_YuQuQuanWenBen, rg_Ju_WeiZhi, rg_Ju_WeiZhi1));
    }
    public static String rg_FanZhuaiWenBen (String rg_YuanWenBen14)  {
        return new StringBuffer(rg_YuanWenBen14).reverse().toString();
    }
    public static String rg_XuanZe (boolean rg_LuoJiZhi, String rg_CanShu, String rg_CanShu1)  {
        return (rg_LuoJiZhi ? rg_CanShu : rg_CanShu1);
    }
    public static String rg_QuWenBenZuoBian (String rg_YuQuJiBuFenDeWenBen, int rg_YuQuChuZiFuDeShuMu)  {
        if(rg_YuQuChuZiFuDeShuMu > rg_YuQuJiBuFenDeWenBen.length() || rg_YuQuChuZiFuDeShuMu < 0 || rg_YuQuJiBuFenDeWenBen.equals("")) return "";
        return rg_YuQuJiBuFenDeWenBen.substring(0, rg_YuQuChuZiFuDeShuMu);
    }
    public static String rg_QuWenBenYouBian (String rg_YuQuJiBuFenDeWenBen1, int rg_YuQuChuZiFuDeShuMu1)  {
        if(rg_YuQuChuZiFuDeShuMu1 > rg_YuQuJiBuFenDeWenBen1.length() || rg_YuQuChuZiFuDeShuMu1 < 0 || rg_YuQuJiBuFenDeWenBen1.equals("")) return "";
        return rg_YuQuJiBuFenDeWenBen1.substring(rg_YuQuJiBuFenDeWenBen1.length() - rg_YuQuChuZiFuDeShuMu1, rg_YuQuJiBuFenDeWenBen1.length());
    }
    public static String rg_QuWenBenZhongJian (String rg_YuQuJiBuFenDeWenBen2, int rg_QiShiQuChuWeiZhi, int rg_YuQuChuZiFuDeShuMu2)  {
        if(rg_YuQuChuZiFuDeShuMu2 > rg_YuQuJiBuFenDeWenBen2.length() || rg_YuQuChuZiFuDeShuMu2 < 0 || rg_QiShiQuChuWeiZhi < 0 || rg_QiShiQuChuWeiZhi > rg_YuQuJiBuFenDeWenBen2.length() ||
        rg_QiShiQuChuWeiZhi + rg_YuQuChuZiFuDeShuMu2 > rg_YuQuJiBuFenDeWenBen2.length() || rg_YuQuJiBuFenDeWenBen2.equals("")) return "";
        return rg_YuQuJiBuFenDeWenBen2.substring(rg_QiShiQuChuWeiZhi - 1, rg_QiShiQuChuWeiZhi + rg_YuQuChuZiFuDeShuMu2 - 1);

    }
}
