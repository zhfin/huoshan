
package rg_ZhiZi.GongJuLei.BianMa;

import java.io.UnsupportedEncodingException;

public class rg_ZhiZi_BianMaLei  {
    public rg_ZhiZi_BianMaLei ()  { }
    public static String rg_BianMaZhuaiHuan (byte [] rg_DaiZhuaiHuanDeZiJieJi, String rg_BianMa)  {
        try { return new String(rg_DaiZhuaiHuanDeZiJieJi, rg_BianMa); } catch (UnsupportedEncodingException e) {} return "";
    }
}
