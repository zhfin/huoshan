
package rg_ZhiZi.GongNeng.DuiHuaKuang;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import java.util.HashMap;

public class rg_ZhiZi_DuiHuaKuang  {
    public rg_ZhiZi_DuiHuaKuang ()  { }
    public static final int rg_AnNiu_ShiNiu = -1;
    public static final int rg_AnNiu_FouNiu = -2;
    public static final int rg_AnNiu_QueDingNiu = -1;
    public static final int rg_AnNiu_QuXiaoNiu = -3;
    public static final int rg_TuBiao_MoTuBiao = 0;
    public static final int rg_TuBiao_DiShi = 17301543;
    public static final int rg_TuBiao_XinXi = 17301659;
    protected static boolean rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang = true;
    protected int rg_TuBiao = 0;
    private HashMap<String, AlertDialog> dialogList = new HashMap<String, AlertDialog>(); 
    public rg_ZhiZi_DuiHuaKuang rg_ZhiTuBiao (int rg_Can_TuBiao)  {
        rg_TuBiao = rg_Can_TuBiao;
        return (this);
    }
    public static void rg_KeFouDianJiWaiMianQuXiao (boolean rg_Can_DianJiWaiMianShiFouQuXiaoDuiHuaKuang)  {
        rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang = rg_Can_DianJiWaiMianShiFouQuXiaoDuiHuaKuang;
    }
    public rg_ZhiZi_DuiHuaKuang rg_PuTongDuiHuaKuang (String rg_Can_BiaoShiFu, rg_HuoShan.AnZhuo.JiTong.AndroidActivity rg_Can_SuoShuChuangKou, String rg_Can_YuXianShiDeBiaoTi, String rg_Can_YuXianShiDeNeiRong)  {
        final rg_HuoShan.AnZhuo.JiTong.AndroidActivity context = rg_Can_SuoShuChuangKou;
        final String title = rg_Can_YuXianShiDeBiaoTi;
        final String message = rg_Can_YuXianShiDeNeiRong;
        final String id = rg_Can_BiaoShiFu;

        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder dialog =  new AlertDialog.Builder(context);
                dialog.setTitle(title);
                dialog.setMessage(message);
                dialog.setIcon(rg_TuBiao);
                dialog.setPositiveButton("确定",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setOnDismissListener(new OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        rg_DangDuiHuaKuangBeiGuanBi(id);
                    }
                });
                AlertDialog alertDialog = dialog.show();
                alertDialog.setCanceledOnTouchOutside(rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang);
                dialogList.put(id, alertDialog);
            }
        });
        return (this);
    }
    public rg_ZhiZi_DuiHuaKuang rg_XunWenDuiHuaKuang (String rg_Can_BiaoShiFu1, rg_HuoShan.AnZhuo.JiTong.AndroidActivity rg_Can_SuoShuChuangKou1, String rg_Can_YuXianShiDeBiaoTi1, String rg_Can_YuXianShiDeNeiRong1, boolean rg_Can_ShiFouXianShiQuXiaoAnNiu)  {
        final rg_HuoShan.AnZhuo.JiTong.AndroidActivity context = rg_Can_SuoShuChuangKou1;
        final String title = rg_Can_YuXianShiDeBiaoTi1;
        final String message = rg_Can_YuXianShiDeNeiRong1;
        final String id = rg_Can_BiaoShiFu1;
        final boolean isShowCancelButton = rg_Can_ShiFouXianShiQuXiaoAnNiu;

        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder dialog =  new AlertDialog.Builder(context);
                dialog.setTitle(title);
                dialog.setMessage(message);
                dialog.setIcon(rg_TuBiao);
                dialog.setPositiveButton("是",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setNegativeButton("否",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                if (isShowCancelButton)
                dialog.setNeutralButton("取消",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setOnDismissListener(new OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        rg_DangDuiHuaKuangBeiGuanBi(id);
                    }
                });
                AlertDialog alertDialog = dialog.show();
                alertDialog.setCanceledOnTouchOutside(rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang);
                dialogList.put(id, alertDialog);
            }
        });
        return (this);
    }
    public rg_ZhiZi_DuiHuaKuang rg_LieBiaoDuiHuaKuang (String rg_Can_BiaoShiFu2, rg_HuoShan.AnZhuo.JiTong.AndroidActivity rg_Can_SuoShuChuangKou2, String rg_Can_YuXianShiDeBiaoTi2, String [] rg_Can_XuanXiang, boolean rg_Can_ShiFouXianShiQuXiaoAnNiu1)  {
        final rg_HuoShan.AnZhuo.JiTong.AndroidActivity context = rg_Can_SuoShuChuangKou2;
        final String title = rg_Can_YuXianShiDeBiaoTi2;
        final String[] item = rg_Can_XuanXiang;
        final String id = rg_Can_BiaoShiFu2;
        final boolean isShowCancelButton = rg_Can_ShiFouXianShiQuXiaoAnNiu1;

        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder dialog =  new AlertDialog.Builder(context);
                dialog.setTitle(title);
                dialog.setItems(item,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setIcon(rg_TuBiao);
                if (isShowCancelButton)
                dialog.setNeutralButton("取消",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setOnDismissListener(new OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        rg_DangDuiHuaKuangBeiGuanBi(id);
                    }
                });
                AlertDialog alertDialog = dialog.show();
                alertDialog.setCanceledOnTouchOutside(rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang);
                dialogList.put(id, alertDialog);
            }
        });
        return (this);
    }
    public rg_ZhiZi_DuiHuaKuang rg_XuanZeDuiHuaKuang (String rg_Can_BiaoShiFu3, rg_HuoShan.AnZhuo.JiTong.AndroidActivity rg_Can_SuoShuChuangKou3, String rg_Can_YuXianShiDeBiaoTi3, String [] rg_Can_XuanXiang1, boolean rg_Can_KeFouDuoXuan, int rg_Can_ChanXuan_MoRenXuanZeXuHao, boolean [] rg_Can_DuoXuan_MoRenXuanZeXuHao, boolean rg_Can_ShiFouXianShiQueDingAnNiu)  {
        final rg_HuoShan.AnZhuo.JiTong.AndroidActivity context = rg_Can_SuoShuChuangKou3;
        final String title = rg_Can_YuXianShiDeBiaoTi3;
        final String[] item = rg_Can_XuanXiang1;
        final String id = rg_Can_BiaoShiFu3;
        final int defaultSingleIndex = rg_Can_ChanXuan_MoRenXuanZeXuHao;
        final boolean[] defaultMultiIndex = rg_Can_DuoXuan_MoRenXuanZeXuHao;
        final boolean isShowOkButton = rg_Can_ShiFouXianShiQueDingAnNiu;
        final boolean isCanMultiChoice = rg_Can_KeFouDuoXuan;

        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder dialog =  new AlertDialog.Builder(context);
                dialog.setTitle(title);
                dialog.setIcon(rg_TuBiao);
                if(isCanMultiChoice){
                dialog.setMultiChoiceItems(item, defaultMultiIndex,
                    new DialogInterface.OnMultiChoiceClickListener() {
                        public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                            rg_DangDuoXiangXuanZeBeiDianJi(id, which, isChecked);
                        }
                    }
                );
                } else {
                    dialog.setSingleChoiceItems(item, defaultSingleIndex,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                rg_DangAnNiuBeiAnXia(id, whichButton);
                            }
                        }
                    );
                }
                if (isShowOkButton)
                dialog.setPositiveButton("确定",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setNeutralButton("取消",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            rg_DangAnNiuBeiAnXia(id, whichButton);
                        }
                    }
                );
                dialog.setOnDismissListener(new OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        rg_DangDuiHuaKuangBeiGuanBi(id);
                    }
                });
                AlertDialog alertDialog = dialog.show();
                alertDialog.setCanceledOnTouchOutside(rg_DianJiWaiMianShiFouQuXiaoDuiHuaKuang);
                dialogList.put(id, alertDialog);
            }
        });
        return (this);
    }
    public boolean rg_GuanBi (String rg_Can_BiaoShiFu4)  {
        if(!dialogList.containsKey(rg_Can_BiaoShiFu4)) return false;
        AlertDialog dialog = dialogList.get(rg_Can_BiaoShiFu4);
        if(dialog == null) return false;
        dialog.dismiss();
        return (true);
    }
    public static interface re_DangDuoXiangXuanZeBeiDianJi  {
        int dispatch (rg_ZhiZi_DuiHuaKuang objSource, String rg_BiaoShiFu, int rg_AnNiuXuHao, boolean rg_ShiFouXuanZe);
    }
    protected re_DangDuoXiangXuanZeBeiDianJi rd_DangDuoXiangXuanZeBeiDianJi;
    public void rl_ZhiZi_DuiHuaKuang_DangDuoXiangXuanZeBeiDianJi (re_DangDuoXiangXuanZeBeiDianJi objListener)  {
        rd_DangDuoXiangXuanZeBeiDianJi = objListener;
    }
    public int rg_DangDuoXiangXuanZeBeiDianJi (String rg_BiaoShiFu, int rg_AnNiuXuHao, boolean rg_ShiFouXuanZe)  {
        if (rd_DangDuoXiangXuanZeBeiDianJi != null)
            return rd_DangDuoXiangXuanZeBeiDianJi.dispatch (this, rg_BiaoShiFu, rg_AnNiuXuHao, rg_ShiFouXuanZe);
        else
            return 0;
    }
    public static interface re_DangAnNiuBeiAnXia  {
        int dispatch (rg_ZhiZi_DuiHuaKuang objSource, String rg_BiaoShiFu1, int rg_AnNiuID);
    }
    protected re_DangAnNiuBeiAnXia rd_DangAnNiuBeiAnXia;
    public void rl_ZhiZi_DuiHuaKuang_DangAnNiuBeiAnXia (re_DangAnNiuBeiAnXia objListener)  {
        rd_DangAnNiuBeiAnXia = objListener;
    }
    public int rg_DangAnNiuBeiAnXia (String rg_BiaoShiFu1, int rg_AnNiuID)  {
        if (rd_DangAnNiuBeiAnXia != null)
            return rd_DangAnNiuBeiAnXia.dispatch (this, rg_BiaoShiFu1, rg_AnNiuID);
        else
            return 0;
    }
    public static interface re_DangDuiHuaKuangBeiGuanBi  {
        int dispatch (rg_ZhiZi_DuiHuaKuang objSource, String rg_BiaoShiFu2);
    }
    protected re_DangDuiHuaKuangBeiGuanBi rd_DangDuiHuaKuangBeiGuanBi;
    public void rl_ZhiZi_DuiHuaKuang_DangDuiHuaKuangBeiGuanBi (re_DangDuiHuaKuangBeiGuanBi objListener)  {
        rd_DangDuiHuaKuangBeiGuanBi = objListener;
    }
    public int rg_DangDuiHuaKuangBeiGuanBi (String rg_BiaoShiFu2)  {
        if (rd_DangDuiHuaKuangBeiGuanBi != null)
            return rd_DangDuiHuaKuangBeiGuanBi.dispatch (this, rg_BiaoShiFu2);
        else
            return 0;
    }
}
