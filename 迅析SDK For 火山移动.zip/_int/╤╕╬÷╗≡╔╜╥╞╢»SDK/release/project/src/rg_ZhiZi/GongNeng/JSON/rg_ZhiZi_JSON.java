
package rg_ZhiZi.GongNeng.JSON;

import com.alibaba.fastjson.*;
import java.util.List;
import java.util.Map;

public class rg_ZhiZi_JSON  {
    public rg_ZhiZi_JSON ()  { }
    public static final String rg_JieXiCuoWu = "PARSE ERROR";
    public static String rg_QuDuiXiangChengYuanZhi (String rg_JSONWenBen, String rg_MingChen1)  {
        try {
            Map<String, Object> map = JSON.parseObject(rg_JSONWenBen);
            Object res = map.get(rg_MingChen1);
            if (res == null) return rg_JieXiCuoWu;
            return res.toString();
        } catch (JSONException e) {
            return rg_JieXiCuoWu;
        }
    }
    public static String rg_QuShuZuChengYuanZhi (String rg_JSONWenBen1, int rg_WeiZhi)  {
        try {
            List<Object> list = JSON.parseArray(rg_JSONWenBen1);
            Object res = list.get(rg_WeiZhi);
            if (res == null) return rg_JieXiCuoWu;
            return res.toString();
        } catch (IndexOutOfBoundsException e) {
            return rg_JieXiCuoWu;
        } catch (JSONException e) {
            return rg_JieXiCuoWu;
        }
    }
    public static int rg_QuDuiXiangChengYuanShu (String rg_JSONWenBen2)  {
        try {
           return JSON.parseObject(rg_JSONWenBen2).size();
        } catch (JSONException e) {
            return 0;
        }
    }
    public static int rg_QuShuZuChengYuanShu (String rg_JSONWenBen3)  {
        try {
            return JSON.parseArray(rg_JSONWenBen3).size();
        } catch (IndexOutOfBoundsException e) {
            return 0;
        } catch (JSONException e) {
            return 0;
        }
    }
}
