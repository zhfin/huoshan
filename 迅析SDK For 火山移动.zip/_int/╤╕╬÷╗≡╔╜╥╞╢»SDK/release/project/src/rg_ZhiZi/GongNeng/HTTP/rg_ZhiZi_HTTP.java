
package rg_ZhiZi.GongNeng.HTTP;

import java.io.IOException;
import okhttp3.*;

public class rg_ZhiZi_HTTP  {
    public rg_ZhiZi_HTTP ()  { }
    protected String rg_WangZhi = "";
    protected String rg_UA = "";
    protected String rg_Cookie = "";
    OkHttpClient client = new OkHttpClient();
    FormBody.Builder builder = new FormBody.Builder();  
    public rg_ZhiZi_HTTP rg_ZhiWangZhi (String rg_Can_WangZhi)  {
        rg_WangZhi = rg_Can_WangZhi;
        return (this);
    }
    public rg_ZhiZi_HTTP rg_ZhiUA (String rg_Can_UA)  {
        rg_UA = rg_Can_UA;
        return (this);
    }
    public rg_ZhiZi_HTTP rg_ZhiCookie (String rg_Can_Cookie)  {
        rg_Cookie = rg_Can_Cookie;
        return (this);
    }
    public rg_ZhiZi_HTTP rg_TianJiaPOSTCanShu (String rg_MingChen, String rg_Zhi)  {
        builder.add(rg_MingChen, rg_Zhi);
        return (this);
    }
    public rg_ZhiZi_HTTP rg_QingKongPOSTCanShu ()  {
        builder = new FormBody.Builder();
        return (this);
    }
    public boolean rg_GET ()  {
        if (rg_ZhiZi.GongJuLei.WenBen.rg_ZhiZi_WenBenGongJuLei.rg_ShiFouWeiKong (rg_WangZhi))
        {
            return (false);
        }
        try {
            final Request request = new Request.Builder().url(rg_WangZhi).header("User-Agent", rg_UA).header("Cookie",rg_Cookie).build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    rg_DangQingQiuShiBaiShi(e.toString());
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    rg_DangQingQiuChengGongShi(response.body().bytes(), response.code(), response.message(), response.header("Set-Cookie"));
                }
            });
        } catch (Exception e) {
            return false;
        }
        return (true);
    }
    public boolean rg_POST ()  {
        if (rg_ZhiZi.GongJuLei.WenBen.rg_ZhiZi_WenBenGongJuLei.rg_ShiFouWeiKong (rg_WangZhi))
        {
            return (false);
        }
        try {
            final Request request = new Request.Builder().url(rg_WangZhi).post(builder.build()).header("User-Agent", rg_UA).header("Cookie",rg_Cookie).build();
            FormBody.Builder builder = new FormBody.Builder();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    rg_DangQingQiuShiBaiShi(e.toString());
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    rg_DangQingQiuChengGongShi(response.body().bytes(), response.code(), response.message(), response.header("Set-Cookie"));
                }
            });
        } catch (Exception e) {
            return false;
        }
        return (true);
    }
    public static interface re_DangQingQiuChengGongShi  {
        int dispatch (rg_ZhiZi_HTTP objSource, byte [] rg_XiangYingNeiRong, int rg_ZhuangTaiMa, String rg_ZhuangTaiXiaoXi, String rg_FanHuiCookie);
    }
    protected re_DangQingQiuChengGongShi rd_DangQingQiuChengGongShi;
    public void rl_ZhiZi_HTTP_DangQingQiuChengGongShi (re_DangQingQiuChengGongShi objListener)  {
        rd_DangQingQiuChengGongShi = objListener;
    }
    public int rg_DangQingQiuChengGongShi (byte [] rg_XiangYingNeiRong, int rg_ZhuangTaiMa, String rg_ZhuangTaiXiaoXi, String rg_FanHuiCookie)  {
        if (rd_DangQingQiuChengGongShi != null)
            return rd_DangQingQiuChengGongShi.dispatch (this, rg_XiangYingNeiRong, rg_ZhuangTaiMa, rg_ZhuangTaiXiaoXi, rg_FanHuiCookie);
        else
            return 0;
    }
    public static interface re_DangQingQiuShiBaiShi  {
        int dispatch (rg_ZhiZi_HTTP objSource, String rg_CuoWuWenBen);
    }
    protected re_DangQingQiuShiBaiShi rd_DangQingQiuShiBaiShi;
    public void rl_ZhiZi_HTTP_DangQingQiuShiBaiShi (re_DangQingQiuShiBaiShi objListener)  {
        rd_DangQingQiuShiBaiShi = objListener;
    }
    public int rg_DangQingQiuShiBaiShi (String rg_CuoWuWenBen)  {
        if (rd_DangQingQiuShiBaiShi != null)
            return rd_DangQingQiuShiBaiShi.dispatch (this, rg_CuoWuWenBen);
        else
            return 0;
    }
}
