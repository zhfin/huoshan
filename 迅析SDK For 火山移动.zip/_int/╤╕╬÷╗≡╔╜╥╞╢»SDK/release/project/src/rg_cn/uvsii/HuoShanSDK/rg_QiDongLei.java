
package rg_cn.uvsii.HuoShanSDK;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class rg_QiDongLei extends rg_HuoShan.AnZhuo.JiTong.AndroidActivity  {
    public rg_QiDongLei ()  { }
    protected rg_HuoShan.AnZhuo.ChuangKou.rg_BiaoQian1 rg_BiaoQian;
    protected rg_ZhiZi.GongNeng.JSON.rg_ZhiZi_JSON rg_XunXi_Lei_json = new rg_ZhiZi.GongNeng.JSON.rg_ZhiZi_JSON ();
    protected rg_ZhiZi.GongJuLei.LeiXingZhuaiHuan.rg_ZhiZi_LeiXingZhuaiHuanLei rg_XunXi_Lei_ZhuaiHuan = new rg_ZhiZi.GongJuLei.LeiXingZhuaiHuan.rg_ZhiZi_LeiXingZhuaiHuanLei ();
    protected rg_ZhiZi.GongJuLei.WenBen.rg_ZhiZi_WenBenGongJuLei rg_XunXi_Lei_WenBenCaoZuo = new rg_ZhiZi.GongJuLei.WenBen.rg_ZhiZi_WenBenGongJuLei ();
    protected rg_ZhiZi.GongNeng.DuiHuaKuang.rg_ZhiZi_DuiHuaKuang rg_XunXi_Lei_DuiHuaKuang = new rg_ZhiZi.GongNeng.DuiHuaKuang.rg_ZhiZi_DuiHuaKuang ();
    protected rg_ZhiZi.GongNeng.HTTP.rg_ZhiZi_HTTP rg_XunXi_Lei_http = new rg_ZhiZi.GongNeng.HTTP.rg_ZhiZi_HTTP ();
    protected int rg_XunXi_CaoZuoBuZhou = 1;
    protected String rg_XunXi_FanHuiNeiRong = "";
    protected static String rg_XunXi_Can_XunXiZhangHao = "";
    protected static String rg_XunXi_Can_SID = "";
    protected static String rg_XunXi_Can_APIKEY = "";
    protected static String rg_XunXi_Can_timestr = "";
    protected static String rg_XunXi_Can_token = "";
    {
        rg_XunXi_Lei_http.rl_ZhiZi_HTTP_DangQingQiuChengGongShi (new rg_ZhiZi.GongNeng.HTTP.rg_ZhiZi_HTTP.re_DangQingQiuChengGongShi ()  {
            public int dispatch (rg_ZhiZi.GongNeng.HTTP.rg_ZhiZi_HTTP objSource, byte [] rg_XiangYingNeiRong, int rg_ZhuangTaiMa, String rg_ZhuangTaiXiaoXi, String rg_FanHuiCookie)  {
                return rg_ZhiZi_HTTP_DangQingQiuChengGongShi (objSource, rg_XiangYingNeiRong, rg_ZhuangTaiMa, rg_ZhuangTaiXiaoXi, rg_FanHuiCookie);
            }
        });
    }
    protected rg_HuoShan.AnZhuo.ChuangKou.rg_XianXingBuJuQi rp_1;
    @Override
    public rg_HuoShan.AnZhuo.ChuangKou.AndroidViewGroup GetAndroidActivityContainer () {
        return rp_1;
    }
    @Override
    protected boolean onInitAndroidActivity () {
        ms_blMainActivityLoaded = true;
        if (super.onInitAndroidActivity () == false)
            return false;
        setContentView (R.layout.rg_qidonglei);
        rp_1 = new rg_HuoShan.AnZhuo.ChuangKou.rg_XianXingBuJuQi ((LinearLayout)findViewById (R.id.rg_qidonglei));

        rg_BiaoQian = new rg_HuoShan.AnZhuo.ChuangKou.rg_BiaoQian1 ((TextView)findViewById (R.id.rg_biaoqian));
        return true;
    }
    public void onStart ()  {
        super.onStart ();





        rg_XunXi_CaoZuoBuZhou = 1;
        rg_XunXi_JieRu ("admin", "XUNXI89965948LDvrGtf", "041392");
    }
    public void rg_XunXi_JieRu (String rg_XunXiZhangHao, String rg_SID, String rg_APIKEY)  {

        if (rg_XunXi_CaoZuoBuZhou == 1)
        {
            rg_XunXi_Can_XunXiZhangHao = rg_XunXiZhangHao;
            rg_XunXi_Can_SID = rg_SID;
            rg_XunXi_Can_APIKEY = rg_APIKEY;
            rg_XunXi_Lei_http.rg_ZhiWangZhi ("http://www.uvsii.cn/api/token.php").rg_TianJiaPOSTCanShu ("user", rg_XunXiZhangHao).rg_TianJiaPOSTCanShu ("sid", rg_SID).rg_TianJiaPOSTCanShu ("apikey", rg_APIKEY).rg_POST ();
        }
        if (rg_XunXi_CaoZuoBuZhou == 2)
        {
            rg_XunXi_Can_timestr = rg_XunXi_Lei_json.rg_QuDuiXiangChengYuanZhi (rg_XunXi_FanHuiNeiRong, "timestr");
            rg_XunXi_Can_token = rg_XunXi_Lei_json.rg_QuDuiXiangChengYuanZhi (rg_XunXi_FanHuiNeiRong, "token");
            rg_XunXi_Lei_http.rg_ZhiWangZhi ("http://www.uvsii.cn/xunxi/statistics.php").rg_TianJiaPOSTCanShu ("SID", rg_XunXi_Can_SID).rg_TianJiaPOSTCanShu ("timestr", rg_XunXi_Can_timestr).rg_TianJiaPOSTCanShu ("key", rg_XunXi_Can_token).rg_POST ();
        }
        if (rg_XunXi_CaoZuoBuZhou == 3)
        {
            rg_XunXi_Lei_http.rg_ZhiWangZhi ("http://www.uvsii.cn/main/gettimes.php").rg_TianJiaPOSTCanShu ("SID", rg_XunXi_Can_SID).rg_TianJiaPOSTCanShu ("timestr", rg_XunXi_Can_timestr).rg_TianJiaPOSTCanShu ("key", rg_XunXi_Can_token).rg_TianJiaPOSTCanShu ("type", "update").rg_POST ();
        }
        if (rg_XunXi_CaoZuoBuZhou == 4)
        {
            rg_XunXi_Lei_http.rg_ZhiWangZhi ("http://www.uvsii.cn/xunxi/timeip.php").rg_TianJiaPOSTCanShu ("SID", rg_XunXi_Can_SID).rg_TianJiaPOSTCanShu ("timestr", rg_XunXi_Can_timestr).rg_TianJiaPOSTCanShu ("key", rg_XunXi_Can_token).rg_POST ();
        }

    }
    protected int rg_ZhiZi_HTTP_DangQingQiuChengGongShi (rg_ZhiZi.GongNeng.HTTP.rg_ZhiZi_HTTP rg_LaiYuanDuiXiang, byte [] rg_XiangYingNeiRong1, int rg_ZhuangTaiMa1, String rg_ZhuangTaiXiaoXi1, String rg_FanHuiCookie1)  {
        rg_XunXi_FanHuiNeiRong = rg_XunXi_Lei_ZhuaiHuan.rg_ZiJieJiDaoWenBen (rg_XiangYingNeiRong1);
        rg_XunXi_CaoZuoBuZhou = rg_XunXi_CaoZuoBuZhou + 1;
        rg_XunXi_JieRu ("", "", "");
        return (0);
    }
}
